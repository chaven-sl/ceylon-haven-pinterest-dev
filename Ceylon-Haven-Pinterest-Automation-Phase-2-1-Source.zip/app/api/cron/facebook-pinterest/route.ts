import { NextRequest, NextResponse } from 'next/server';
import { getValidatedEnv } from '@/lib/env';

export const dynamic = 'force-dynamic';
export const maxDuration = 60; // Vercel Hobby tier limit

/**
 * Cron endpoint for automated Facebook → Pinterest publishing.
 * Validates CRON_SECRET via Authorization header.
 *
 * Schedule: Daily at 06:30 UTC (12:00 PM Asia/Colombo)
 * Cron expression: 30 6 * * *
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  const startTime = Date.now();

  try {
    // Validate CRON_SECRET from Authorization header
    const authHeader = request.headers.get('authorization');
    const env = getValidatedEnv();

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        {
          error: 'Unauthorized',
          message: 'Missing or invalid Authorization header',
          phase: 'Phase 2',
        },
        { status: 401 },
      );
    }

    const providedSecret = authHeader.substring('Bearer '.length);
    if (providedSecret !== env.CRON_SECRET) {
      return NextResponse.json(
        {
          error: 'Unauthorized',
          message: 'Invalid CRON_SECRET',
          phase: 'Phase 2',
        },
        { status: 401 },
      );
    }

    // Phase 2: Mock/no-op behavior
    // No real API calls are made
    const endTime = Date.now();
    const durationMs = endTime - startTime;

    return NextResponse.json(
      {
        success: true,
        phase: 'Phase 2',
        message: 'Cron execution started (mock behavior - no real API calls)',
        timestamp: new Date().toISOString(),
        executionId: `exec_${Date.now()}_${Math.random().toString(36).substring(7)}`,
        schedule: {
          frequency: 'Daily',
          time: '06:30 UTC (12:00 AM Asia/Colombo)',
          timezone: 'UTC',
          note: 'Note: User specified "noon" = 12:00 PM, so actual schedule is 06:30 UTC (12:00 PM AST+5:30)',
        },
        phaseSummary: {
          phase: '2',
          status: 'Foundation',
          realApiCallsMade: 0,
          facebookApiCalls: 0,
          pinterestApiCalls: 0,
          realPinCreated: false,
          deploymentTarget: 'Local only - no production deployment',
        },
        duration: {
          ms: durationMs,
          seconds: (durationMs / 1000).toFixed(2),
        },
      },
      { status: 200 },
    );
  } catch (error) {
    const endTime = Date.now();
    const durationMs = endTime - startTime;

    console.error('[cron/facebook-pinterest] Error:', error);

    return NextResponse.json(
      {
        error: 'Internal server error',
        message: error instanceof Error ? error.message : 'Unknown error',
        phase: 'Phase 2',
        duration: {
          ms: durationMs,
          seconds: (durationMs / 1000).toFixed(2),
        },
      },
      { status: 500 },
    );
  }
}

/**
 * GET handler: Return documentation and status
 */
export async function GET(): Promise<NextResponse> {
  return NextResponse.json(
    {
      endpoint: '/api/cron/facebook-pinterest',
      method: 'POST',
      auth: 'Bearer token in Authorization header (CRON_SECRET)',
      phase: 'Phase 2',
      status: 'Mock behavior - no real API calls',
      schedule: 'Daily at 06:30 UTC (12:00 PM Asia/Colombo)',
      documentation: {
        cronExpression: '30 6 * * *',
        frequency: 'Daily',
        timezone: 'UTC',
        note: 'User specified "noon" = 12:00 PM, so 06:30 UTC = 12:00 PM in Asia/Colombo (UTC+5:30)',
      },
      realApiActivity: {
        facebookApiCalls: 0,
        pinterestApiCalls: 0,
        pinsCreated: 0,
        productionDeployed: false,
      },
    },
    { status: 200 },
  );
}
