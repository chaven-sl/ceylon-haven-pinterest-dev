# Changelog

All notable changes to the Ceylon Haven Facebook → Pinterest Automation project are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [Phase 2.0] - 2026-09-03 (Foundation & State Machine)

**Timestamp:** 2026-09-03 14:37 UTC  
**Phase:** 2.0 - Application Foundation

### Implementation Complete

**Project Structure:**
- Next.js 14 App Router with TypeScript
- Strict type checking enabled
- ESLint and Prettier configured
- Vitest test framework

**Core Components Implemented:**

1. **Environment Validation** (`lib/env.ts`)
   - Zod schema for required and optional variables
   - Never logs secrets
   - Cached validation

2. **State Machine** (`lib/state/transitions.ts`)
   - Valid transitions: discovered → publishing → published/failed/uncertain/skipped
   - Atomic claim logic (discovered → publishing)
   - Retry limits (MAX_RETRIES = 3)
   - Terminal states: published, uncertain, skipped
   - Comprehensive transition validation

3. **Database Operations** (`db/operations.ts`)
   - Atomic claims with conditional UPDATE
   - Post state transitions
   - Pin recording (atomically creates pin + transitions post)
   - Error handling for uncertain states

4. **Database Schema** (`db/migrations/0001_init_schema.sql`)
   - facebook_posts table with status ENUM
   - pinterest_pins table with foreign key
   - execution_logs table for audit trail
   - Row-Level Security (RLS) enabled
   - Comprehensive indexes

5. **Post Classification** (`lib/classify.ts`)
   - single-image: supported
   - video, reel, text-only, no-image: skipped
   - Image URL validation (HTTPS only)

6. **Mock Services** (`services/mock-pinterest.ts`)
   - Fake pin creation (never calls real API)
   - In-memory pin store for testing
   - Clear mock identifiers

7. **Test Fixtures** (`services/fixtures.ts`)
   - 8 representative Facebook post types
   - Supported: single-image posts
   - Skipped: video, reel, text-only, missing-image

8. **API Endpoints:**
   - `/api/health` - Health check without secrets
   - `/api/cron/facebook-pinterest` - Cron entry point (mock behavior)

9. **Comprehensive Tests** (83 passing tests)
   - State machine transitions: 30 tests
   - Post classification: 18 tests
   - End-to-end orchestration: 10 tests
   - Environment validation: 14 tests
   - Mock services: 11 tests

### Test Coverage Highlights

- ✓ All valid state transitions
- ✓ Blocking invalid transitions (e.g., published → publishing)
- ✓ Atomic claims (concurrent safety)
- ✓ Retry limits enforcement
- ✓ Uncertain state protection (no auto-retry)
- ✓ Skipped state persistence
- ✓ Pin uniqueness per post
- ✓ Failure simulation: uncertain state prevents duplicates
- ✓ Classification for all post types
- ✓ Mock orchestration without real APIs

### Quality Assurance

- ✓ TypeScript strict mode passes (0 errors)
- ✓ ESLint passes (0 errors)
- ✓ 83 tests passing
- ✓ No real API calls made
- ✓ No production deployment
- ✓ No real pins created

### API Activity

- Facebook API calls: 0
- Pinterest API calls: 0
- Real pins created: 0
- Deployment: Local only

### Performance

- Test suite: 2.02s (83 tests)
- Type checking: < 1s
- Linting: < 1s
- Build-ready

### Files Created/Modified

- **New:** app/, lib/, db/, services/, tests/
- **New:** 15+ source files
- **New:** 5 test files (83 tests total)
- **New:** SQL migration
- **Modified:** package.json, tsconfig.json, .eslintrc.json

### Known Limitations (Phase 2)

- No real Facebook API integration (mock only)
- No real Pinterest API integration (mock only)
- Health endpoint does not validate database connectivity
- Cron endpoint returns mock responses
- No automated schema migration runner

### Next Phase (Phase 3)

- Real Facebook Graph API integration
- Real Pinterest API integration
- Content adaptation templates
- Board routing rules
- Comprehensive error handling
- Monitoring and alerting

---

## [Phase 1.6] - 2026-09-03 (Consistency & Idempotency Correction)

### Final Architecture Consistency Pass

**Timestamp:** 2026-09-03 15:00 UTC  
**Phase:** 1.6 - Post-Phase-1.5 Audit & Correction

**Changes Made:**

**Repository Consistency Audit:**
- Removed 8 active Netlify references from implementation sections
- Historical Phase 1 changelog entries retained (clearly marked)
- All active implementation instructions now use Vercel exclusively

**Table Naming Standardization:**
- `processed_posts` → `facebook_posts` throughout
- `facebook_posts_processed` → `facebook_posts`
- Reason: Posts are not necessarily already "processed"; table tracks full lifecycle

**Idempotency Model Correction (CRITICAL):**
- Old model (WRONG): idempotency_key = hash(execution_timestamp + facebook_post_id)
- New model (CORRECT): idempotency_key = facebook_post_id (stable identity)
- Rationale: Retries within same execution or next-day runs would generate different old keys
- Solution: facebook_post_id is the stable business identity; execution timestamp is observability only
- Database enforcement: UNIQUE constraint on facebook_post_id guarantees at most one pin per post

**State Machine Documentation (NEW):**
- Added explicit state lifecycle: discovered → publishing → published/failed/uncertain/skipped
- Atomic transition from discovered→publishing prevents concurrent processing
- Uncertain state handles Pinterest success without DB confirmation
- Skipped state prevents re-processing unsupported post types

**Facebook Post Type Scope Clarification (NEW):**
- V1 WILL PROCESS: single-image posts
- V1 WILL EVALUATE: multi-image/album (pick primary)
- V1 WILL SKIP: video, Reel, text-only, no-image posts
- Skipped posts stored with structured skip_reason

**Assumption Documentation (NEW):**
- Facebook Graph v26 attachment structures (to be validated)
- Facebook image URL stability
- Image URL → Pinterest media_source compatibility (no re-hosting in V1)

**Performance Log Cleanup:**
- Removed unsupported precision ("1,369 years to fill")
- Separated ESTIMATED vs MEASURED
- Removed implied success rates without data basis

**Files Affected:**
- ARCHITECTURE_PHASE1.md (major revision: table names, idempotency model, state machine, scope)
- CHANGELOG.md (this entry + historical preservation)
- PERFORMANCE_LOG.md (removed vague projections)
- README.md (table name updates)
- PROJECT_STATUS.md (Netlify→Vercel reference fix)

**Reason:**
Phase 1.5 infrastructure changes were approved but discovery in preparation for Phase 2 revealed consistency gaps and a critical idempotency design flaw. The execution-timestamp-based key would not prevent duplicates across retries. Phase 1.6 corrects these issues and explicitly documents the state machine logic.

**Testing Passed:**
N/A (Phase 1.6 is documentation correction; no code yet)

---

## [Phase 1.5] - 2026-09-03 (Infrastructure Revision)

### Infrastructure Platform Change

**Timestamp:** 2026-09-03 14:00 UTC  
**Phase:** 1.5 - Architecture Revision (Post-Phase-1 feedback)

**Changes Made:**

**Infrastructure Platform:** Revised from Netlify to Vercel
- Original Phase 1 recommendation: Netlify Scheduled Functions + Supabase
- Phase 1.5 revision: Vercel Functions + Vercel Cron Jobs + Supabase
- Reason: Business has established Vercel account with existing applications; reduces operational fragmentation
- Technical findings: Vercel Cron Jobs support once-daily execution on free tier; functions timeout sufficient (60s)
- This is an operational/business decision, not a technical limitation

**Updated Documentation:**
- ARCHITECTURE_PHASE1.md: Complete infrastructure rework (Netlify → Vercel)
- DECISIONS.md: Added Decision 1 (Vercel + Supabase); moved original Netlify decision to Decision 1.5 (historical)
- TECH_REFERENCE.md: All Netlify references replaced with Vercel equivalents
- TECH_REFERENCE.md: Vercel Cron configuration in `vercel.json`
- TECH_REFERENCE.md: Route Handler template (Next.js App Router)
- TECH_REFERENCE.md: CRON_SECRET validation middleware

**Meta Graph API Version Updated:**
- Facebook Graph API version: v19.0 → v26 (current as of July 2026)
- All endpoints updated to v26
- No breaking changes identified in v19→v26 migration

**Pinterest API Correction:**
- Corrected media_source payload structure in TECH_REFERENCE.md
- Proper format: `media_source: { source_type: "image_url", url: "..." }`
- Documented carousel pin support via `multiple_image_urls`

**Supabase Security Improvements:**
- Distinguished between anon key (client-side) and service_role key (server-side)
- Service_role key storage in Vercel Environment Variables only
- Added Row-Level Security (RLS) architecture notes
- Environment variable best practices: never expose service_role via NEXT_PUBLIC_

**Database Schema Enhancements:**
- Renamed `processed_posts` → `facebook_posts_processed` for clarity
- Added `idempotency_key` field for robust retry semantics
- Added `execution_id` to `execution_logs` for traceability
- Enhanced indexes for performance

**Files Affected:**
- ARCHITECTURE_PHASE1.md (major revision)
- DECISIONS.md (new decision + historical note)
- TECH_REFERENCE.md (comprehensive Netlify → Vercel migration)
- .env.example (added CRON_SECRET, FB_GRAPH_API_VERSION)
- CHANGELOG.md (this entry + historical note)

**Reason:**
Post-Phase-1 business feedback clarified that Vercel is the approved platform for Ceylon Haven applications. Concurrent research discovered current Vercel Cron Jobs (60s timeout, once-daily support) are adequate for this workload. Phase 1.5 ensures architecture aligns with business infrastructure and incorporates latest API versions + security best practices discovered during revision.

**Testing Passed:**
N/A (Phase 1.5 is documentation revision; no code changes)

---

## [Phase 1] - 2026-09-03

### Research & Planning

**Timestamp:** 2026-09-03 12:00 UTC  
**Phase:** 1 - Architecture & Feasibility Assessment

**Changes Made:**
- Completed Facebook Graph API capability research
  - Confirmed: `/page_id/feed` endpoint returns posts with text + media
  - Permissions required: pages_show_list (no review), pages_read_engagement (review required for advanced features)
  - Page Access Token lifespan: permanent (doesn't expire); Data Access permissions refresh every 90 days
  - Graph API documentation updated 2026-05-07
  
- Completed Pinterest API capability research
  - Confirmed: `POST /v5/pins` endpoint creates pins
  - Rate limits: 100 write ops/minute per user per app; 1000 ops/day limit on Standard tier
  - Access tokens: 30-day lifespan; refresh tokens continuous (60-day rolling refresh)
  - Pinterest requires Business account + app registration; Standard access requires video demo submission

- Completed infrastructure evaluation
  - Netlify Functions: 300 free credits/month; scheduled functions run daily at no incremental cost
  - Supabase: 500MB free storage; sufficient for deduplication log + execution records
  - Cloudflare Workers: Cron triggers free but limited to 3 per worker; less suitable for future expansion
  - Decision: Netlify + Supabase chosen as lowest TCO for low-volume use case

- Designed minimal database schema
  - `processed_posts` table: tracks Facebook posts to prevent duplicates
  - `pinterest_pins` table: maps Facebook post to Pinterest pin ID
  - `execution_logs` table: records each scheduled run for observability
  - Schema supports future board routing without redesign

- Designed failure handling strategy
  - Graceful degradation: API failures logged, retry attempted up to 3 times with exponential backoff
  - Duplicate prevention: database transactions ensure same post never creates multiple pins
  - Token refresh: proactive refresh every 25 days prevents expiration during execution

- Documented 8 architectural decisions
  - Rationale, alternatives considered, and future implications recorded in DECISIONS.md
  - Prevents reconsidering settled architectural choices in future sessions

- Created project scaffolding
  - .env.example: documents required environment variables
  - Repository structure designed for clarity and maintainability
  - Security model: all secrets via environment variables, never hardcoded

**Files Affected:**
- `.env.example` (created)
- `DECISIONS.md` (created)
- `PROJECT_STATUS.md` (created)
- `CHANGELOG.md` (created)
- `PERFORMANCE_LOG.md` (created)
- `ARCHITECTURE_PHASE1.md` (created)

**Reason:**
Phase 1 objective: assess feasibility and produce implementation roadmap before Phase 2 coding begins. All objectives complete.

**Testing Passed:**
N/A (Phase 1 is research/planning; no code to test)

---

## Upcoming Changes (Phase 2)

The following changes are planned for Phase 2 but not yet implemented:

- [ ] Project scaffolding: Node.js/TypeScript setup with dependencies
- [ ] Database schema: Supabase migration files for table creation
- [ ] Facebook integration: Graph API client + post retrieval logic
- [ ] Pinterest integration: API client + pin creation stub
- [ ] Scheduled function: Netlify Functions entry point + orchestration
- [ ] Deduplication logic: transaction-safe duplicate detection
- [ ] Token refresh logic: automatic token refresh every 25 days
- [ ] Logging infrastructure: execution logs → Supabase
- [ ] Error handling: retry logic with exponential backoff
- [ ] Environment variables: .env validation at startup

---

## Notes for Future Sessions

- Facebook Page Access Token does not expire, but Data Access permissions must be manually renewed every 90 days (reminder system recommended)
- Pinterest tokens are time-limited; implement proactive refresh to prevent runtime failures
- Netlify Free plan includes 300 credits/month; each daily scheduled execution costs ~2-5 credits (sustainable)
- Supabase free tier auto-pauses after 1 week of inactivity; production tier recommended after MVP validation
- No App Review required to test Facebook integration against your own page (development mode)
- Pinterest requires video demo + manual review for Standard access; test with Trial access first
