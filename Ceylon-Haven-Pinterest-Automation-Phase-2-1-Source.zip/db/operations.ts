import { SupabaseClient } from '@supabase/supabase-js';

export type ClaimResult = 'success' | 'already_claimed' | 'not_found';

export interface AtomicClaimResponse {
  result: ClaimResult;
  facebookPostId: string;
  message: string;
}

/**
 * Atomically claim a Facebook post for publishing.
 * Uses a database transaction to ensure only one process can claim a post.
 *
 * @param client Supabase client
 * @param facebookPostId The Facebook post ID to claim
 * @returns ClaimResult indicating success, already_claimed, or not_found
 */
export async function claimForPublishing(
  client: SupabaseClient,
  facebookPostId: string,
): Promise<AtomicClaimResponse> {
  // Atomic UPDATE with conditional check
  // Only transition from 'discovered' to 'publishing' if currently 'discovered'
  const { data, error } = await client
    .from('facebook_posts')
    .update({
      status: 'publishing',
      updated_at: new Date().toISOString(),
    })
    .eq('facebook_post_id', facebookPostId)
    .eq('status', 'discovered')
    .select('facebook_post_id, status')
    .single();

  if (error) {
    // Handle "no rows" scenario
    if (error.code === 'PGRST116') {
      // First check if the post exists at all
      const { data: existingPost, error: fetchError } = await client
        .from('facebook_posts')
        .select('facebook_post_id, status')
        .eq('facebook_post_id', facebookPostId)
        .single();

      if (fetchError || !existingPost) {
        return {
          result: 'not_found',
          facebookPostId,
          message: `Post ${facebookPostId} not found in database`,
        };
      }

      // Post exists but is not in 'discovered' state
      return {
        result: 'already_claimed',
        facebookPostId,
        message: `Post ${facebookPostId} is already in state: ${existingPost.status}`,
      };
    }

    throw new Error(`Atomic claim failed for ${facebookPostId}: ${error.message}`);
  }

  if (!data) {
    return {
      result: 'already_claimed',
      facebookPostId,
      message: `Post ${facebookPostId} could not be claimed (may be in progress)`,
    };
  }

  return {
    result: 'success',
    facebookPostId,
    message: `Post ${facebookPostId} successfully claimed for publishing`,
  };
}

/**
 * Record a successfully published Pinterest pin.
 * Atomically creates a pin record and transitions the post to 'published'.
 *
 * @param client Supabase client
 * @param facebookPostId The Facebook post ID
 * @param pinterestPinId The Pinterest pin ID
 * @param boardName The board name where pin was created
 * @param destinationUrl The URL the pin links to
 * @returns true if successful, throws on error
 */
export async function recordPublishedPin(
  client: SupabaseClient,
  facebookPostId: string,
  pinterestPinId: string,
  boardName: string,
  destinationUrl: string,
): Promise<boolean> {
  // Use a transaction-like approach: insert pin record and update post status together
  const now = new Date().toISOString();

  // First insert the pin record
  const { error: insertError } = await client.from('pinterest_pins').insert({
    facebook_post_id: facebookPostId,
    pinterest_pin_id: pinterestPinId,
    pinterest_pin_url: `https://pinterest.com/pin/${pinterestPinId}`,
    board_name: boardName,
    destination_url: destinationUrl,
    status: 'published',
    created_at: now,
    updated_at: now,
  });

  if (insertError) {
    // Duplicate pin for this facebook_post_id
    if (insertError.code === '23505') {
      throw new Error(
        `Duplicate pin record for facebook_post_id ${facebookPostId}: pin already published`,
      );
    }
    throw new Error(`Failed to record published pin: ${insertError.message}`);
  }

  // Now update the facebook post to 'published'
  const { error: updateError } = await client
    .from('facebook_posts')
    .update({
      status: 'published',
      updated_at: now,
    })
    .eq('facebook_post_id', facebookPostId);

  if (updateError) {
    throw new Error(`Failed to update post status to published: ${updateError.message}`);
  }

  return true;
}

/**
 * Update a post to 'failed' status with error information.
 *
 * @param client Supabase client
 * @param facebookPostId The Facebook post ID
 * @param errorMessage The error message/reason for failure
 * @param incrementRetryCount Whether to increment the retry count
 * @returns true if successful
 */
export async function markPostFailed(
  client: SupabaseClient,
  facebookPostId: string,
  errorMessage: string,
  incrementRetryCount: boolean = true,
): Promise<boolean> {
  const now = new Date().toISOString();

  const { error } = await client
    .from('facebook_posts')
    .update({
      status: 'failed',
      last_error: errorMessage,
      retry_count: incrementRetryCount ? (await getRetryCount(client, facebookPostId)) + 1 : 0,
      updated_at: now,
    })
    .eq('facebook_post_id', facebookPostId);

  if (error) {
    throw new Error(`Failed to mark post as failed: ${error.message}`);
  }

  return true;
}

/**
 * Update a post to 'uncertain' status (published but not confirmed in DB).
 *
 * @param client Supabase client
 * @param facebookPostId The Facebook post ID
 * @param errorMessage The error message explaining uncertainty
 * @returns true if successful
 */
export async function markPostUncertain(
  client: SupabaseClient,
  facebookPostId: string,
  errorMessage: string,
): Promise<boolean> {
  const now = new Date().toISOString();

  const { error } = await client
    .from('facebook_posts')
    .update({
      status: 'uncertain',
      last_error: errorMessage,
      updated_at: now,
    })
    .eq('facebook_post_id', facebookPostId);

  if (error) {
    throw new Error(`Failed to mark post as uncertain: ${error.message}`);
  }

  return true;
}

/**
 * Update a post to 'skipped' status with reason.
 *
 * @param client Supabase client
 * @param facebookPostId The Facebook post ID
 * @param skipReason The reason for skipping
 * @returns true if successful
 */
export async function markPostSkipped(
  client: SupabaseClient,
  facebookPostId: string,
  skipReason: string,
): Promise<boolean> {
  const now = new Date().toISOString();

  const { error } = await client
    .from('facebook_posts')
    .update({
      status: 'skipped',
      skip_reason: skipReason,
      updated_at: now,
    })
    .eq('facebook_post_id', facebookPostId);

  if (error) {
    throw new Error(`Failed to mark post as skipped: ${error.message}`);
  }

  return true;
}

/**
 * Get current retry count for a post.
 *
 * @param client Supabase client
 * @param facebookPostId The Facebook post ID
 * @returns Current retry count
 */
export async function getRetryCount(
  client: SupabaseClient,
  facebookPostId: string,
): Promise<number> {
  const { data, error } = await client
    .from('facebook_posts')
    .select('retry_count')
    .eq('facebook_post_id', facebookPostId)
    .single();

  if (error || !data) {
    return 0;
  }

  return data.retry_count || 0;
}
